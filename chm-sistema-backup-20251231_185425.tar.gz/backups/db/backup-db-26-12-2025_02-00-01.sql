-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: 186.209.113.108    Database: chmtrans_chm-sistema
-- ------------------------------------------------------
-- Server version	5.5.5-10.11.14-MariaDB-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `chm_accounts_payable`
--

DROP TABLE IF EXISTS `chm_accounts_payable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chm_accounts_payable` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `description` varchar(255) NOT NULL,
  `category` varchar(100) DEFAULT NULL,
  `supplier` varchar(150) DEFAULT NULL,
  `due_date` date NOT NULL,
  `value` decimal(10,2) NOT NULL,
  `paid_value` decimal(10,2) NOT NULL DEFAULT 0.00,
  `paid_at` datetime DEFAULT NULL,
  `payment_method` enum('cash','pix','credit','debit','transfer','boleto') DEFAULT NULL,
  `status` enum('pending','partial','paid','overdue','cancelled') NOT NULL DEFAULT 'pending',
  `recurrent` tinyint(1) NOT NULL DEFAULT 0,
  `recurrent_type` enum('weekly','monthly','yearly') DEFAULT NULL,
  `booking_id` int(10) unsigned DEFAULT NULL,
  `driver_id` int(10) unsigned DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chm_accounts_payable`
--

LOCK TABLES `chm_accounts_payable` WRITE;
/*!40000 ALTER TABLE `chm_accounts_payable` DISABLE KEYS */;
/*!40000 ALTER TABLE `chm_accounts_payable` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chm_accounts_receivable`
--

DROP TABLE IF EXISTS `chm_accounts_receivable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chm_accounts_receivable` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `description` varchar(255) NOT NULL,
  `category` varchar(100) DEFAULT NULL,
  `client_id` int(10) unsigned DEFAULT NULL,
  `booking_id` int(10) unsigned DEFAULT NULL,
  `due_date` date NOT NULL,
  `value` decimal(10,2) NOT NULL,
  `received_value` decimal(10,2) NOT NULL DEFAULT 0.00,
  `received_at` datetime DEFAULT NULL,
  `payment_method` enum('cash','pix','credit','debit','transfer','invoice') DEFAULT NULL,
  `status` enum('pending','partial','received','overdue','cancelled') NOT NULL DEFAULT 'pending',
  `notes` text DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chm_accounts_receivable`
--

LOCK TABLES `chm_accounts_receivable` WRITE;
/*!40000 ALTER TABLE `chm_accounts_receivable` DISABLE KEYS */;
/*!40000 ALTER TABLE `chm_accounts_receivable` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chm_backups`
--

DROP TABLE IF EXISTS `chm_backups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chm_backups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  `size` bigint(20) unsigned NOT NULL DEFAULT 0,
  `type` enum('auto','manual') NOT NULL DEFAULT 'auto',
  `status` enum('completed','failed') NOT NULL DEFAULT 'completed',
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chm_backups`
--

LOCK TABLES `chm_backups` WRITE;
/*!40000 ALTER TABLE `chm_backups` DISABLE KEYS */;
/*!40000 ALTER TABLE `chm_backups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chm_bookings`
--

DROP TABLE IF EXISTS `chm_bookings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chm_bookings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL,
  `client_id` int(10) unsigned NOT NULL,
  `driver_id` int(10) unsigned DEFAULT NULL,
  `vehicle_id` int(10) unsigned DEFAULT NULL,
  `service_type` enum('transfer','hourly','daily','airport','executive','event') NOT NULL DEFAULT 'transfer',
  `date` date NOT NULL,
  `time` time NOT NULL,
  `end_date` date DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `origin` varchar(255) NOT NULL,
  `destination` varchar(255) DEFAULT NULL,
  `stops` text DEFAULT NULL,
  `passengers` tinyint(3) unsigned NOT NULL DEFAULT 1,
  `passenger_name` varchar(150) DEFAULT NULL,
  `passenger_phone` varchar(20) DEFAULT NULL,
  `flight_number` varchar(20) DEFAULT NULL,
  `flight_origin` varchar(100) DEFAULT NULL,
  `flight_arrival` time DEFAULT NULL,
  `distance` decimal(10,2) DEFAULT NULL,
  `duration` int(10) unsigned DEFAULT NULL,
  `value` decimal(10,2) NOT NULL DEFAULT 0.00,
  `extras` decimal(10,2) NOT NULL DEFAULT 0.00,
  `discount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total` decimal(10,2) NOT NULL DEFAULT 0.00,
  `commission_rate` decimal(5,2) NOT NULL DEFAULT 11.00,
  `commission_value` decimal(10,2) NOT NULL DEFAULT 0.00,
  `payment_method` enum('cash','pix','credit','debit','transfer','invoice') NOT NULL DEFAULT 'pix',
  `payment_status` enum('pending','partial','paid') NOT NULL DEFAULT 'pending',
  `paid_at` datetime DEFAULT NULL,
  `status` enum('pending','confirmed','in_progress','completed','cancelled') NOT NULL DEFAULT 'pending',
  `cancelled_at` datetime DEFAULT NULL,
  `cancelled_reason` text DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `internal_notes` text DEFAULT NULL,
  `voucher_sent` tinyint(1) NOT NULL DEFAULT 0,
  `voucher_sent_at` datetime DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chm_bookings`
--

LOCK TABLES `chm_bookings` WRITE;
/*!40000 ALTER TABLE `chm_bookings` DISABLE KEYS */;
/*!40000 ALTER TABLE `chm_bookings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chm_calendar_events`
--

DROP TABLE IF EXISTS `chm_calendar_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chm_calendar_events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `google_uid` varchar(255) DEFAULT NULL,
  `title` varchar(500) NOT NULL,
  `description` text DEFAULT NULL,
  `location` varchar(500) DEFAULT NULL,
  `start_datetime` datetime NOT NULL,
  `end_datetime` datetime DEFAULT NULL,
  `all_day` tinyint(1) DEFAULT 0,
  `color` varchar(20) DEFAULT '#1a73e8',
  `source` varchar(50) DEFAULT 'manual',
  `user_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `google_uid` (`google_uid`),
  KEY `idx_start` (`start_datetime`),
  KEY `idx_user` (`user_id`),
  KEY `idx_source` (`source`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chm_calendar_events`
--

LOCK TABLES `chm_calendar_events` WRITE;
/*!40000 ALTER TABLE `chm_calendar_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `chm_calendar_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chm_clients`
--

DROP TABLE IF EXISTS `chm_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chm_clients` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `type` enum('pf','pj') NOT NULL DEFAULT 'pf',
  `name` varchar(150) NOT NULL,
  `client_number` varchar(20) DEFAULT NULL,
  `trade_name` varchar(150) DEFAULT NULL,
  `document` varchar(20) NOT NULL,
  `rg` varchar(20) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `phone2` varchar(20) DEFAULT NULL,
  `whatsapp` varchar(20) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `address_number` varchar(20) DEFAULT NULL,
  `address_complement` varchar(100) DEFAULT NULL,
  `neighborhood` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` char(2) DEFAULT NULL,
  `zipcode` varchar(10) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_document` (`document`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chm_clients`
--

LOCK TABLES `chm_clients` WRITE;
/*!40000 ALTER TABLE `chm_clients` DISABLE KEYS */;
/*!40000 ALTER TABLE `chm_clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chm_drivers`
--

DROP TABLE IF EXISTS `chm_drivers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chm_drivers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(150) NOT NULL,
  `driver_number` varchar(50) DEFAULT NULL,
  `document` varchar(20) NOT NULL,
  `rg` varchar(20) DEFAULT NULL,
  `cnh` varchar(20) NOT NULL,
  `cnh_category` varchar(5) NOT NULL,
  `cnh_expiry` date NOT NULL,
  `birth_date` date DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `phone2` varchar(20) DEFAULT NULL,
  `whatsapp` varchar(20) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `address_number` varchar(20) DEFAULT NULL,
  `address_complement` varchar(100) DEFAULT NULL,
  `neighborhood` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` char(2) DEFAULT NULL,
  `zipcode` varchar(10) DEFAULT NULL,
  `pix_key` varchar(100) DEFAULT NULL,
  `bank_name` varchar(100) DEFAULT NULL,
  `bank_agency` varchar(20) DEFAULT NULL,
  `bank_account` varchar(30) DEFAULT NULL,
  `commission_rate` decimal(5,2) NOT NULL DEFAULT 11.00,
  `type` enum('proprio','terceirizado') NOT NULL DEFAULT 'proprio',
  `photo` varchar(255) DEFAULT NULL,
  `car_photo` varchar(255) DEFAULT NULL,
  `cnh_photo` varchar(255) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_document` (`document`),
  UNIQUE KEY `uk_cnh` (`cnh`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chm_drivers`
--

LOCK TABLES `chm_drivers` WRITE;
/*!40000 ALTER TABLE `chm_drivers` DISABLE KEYS */;
/*!40000 ALTER TABLE `chm_drivers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chm_logs`
--

DROP TABLE IF EXISTS `chm_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chm_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `module` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `data` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chm_logs`
--

LOCK TABLES `chm_logs` WRITE;
/*!40000 ALTER TABLE `chm_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `chm_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chm_settings`
--

DROP TABLE IF EXISTS `chm_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chm_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `setting_type` enum('string','integer','float','boolean','json') NOT NULL DEFAULT 'string',
  `setting_group` varchar(50) NOT NULL DEFAULT 'general',
  `description` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_key` (`setting_key`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chm_settings`
--

LOCK TABLES `chm_settings` WRITE;
/*!40000 ALTER TABLE `chm_settings` DISABLE KEYS */;
INSERT INTO `chm_settings` VALUES (1,'company_name','CHM Transportes Executivos','string','general',NULL,'2025-12-25 00:41:19','2025-12-25 00:41:19'),(2,'company_document','','string','general',NULL,'2025-12-25 00:41:19','2025-12-25 00:41:19'),(3,'company_phone','','string','general',NULL,'2025-12-25 00:41:19','2025-12-25 00:41:19'),(4,'company_email','contato@chmtransportes.com.br','string','general',NULL,'2025-12-25 00:41:19','2025-12-25 00:41:19'),(5,'company_address','','string','general',NULL,'2025-12-25 00:41:19','2025-12-25 00:41:19'),(6,'default_commission','11','string','general',NULL,'2025-12-25 00:41:19','2025-12-25 00:41:19'),(7,'whatsapp_enabled','0','string','general',NULL,'2025-12-25 00:41:19','2025-12-25 00:41:19'),(8,'backup_enabled','1','string','general',NULL,'2025-12-25 00:41:19','2025-12-25 00:41:19'),(9,'backup_interval','10','string','general',NULL,'2025-12-25 00:41:19','2025-12-25 00:41:19');
/*!40000 ALTER TABLE `chm_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chm_users`
--

DROP TABLE IF EXISTS `chm_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chm_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `profile` tinyint(3) unsigned NOT NULL DEFAULT 3,
  `avatar` varchar(255) DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `email_verified_at` datetime DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `reset_token` varchar(100) DEFAULT NULL,
  `reset_token_expires` datetime DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `login_attempts` int(10) unsigned NOT NULL DEFAULT 0,
  `locked_until` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chm_users`
--

LOCK TABLES `chm_users` WRITE;
/*!40000 ALTER TABLE `chm_users` DISABLE KEYS */;
INSERT INTO `chm_users` VALUES (1,'Administrador CHM','chm@chmtransportes.com.br','$2y$10$hpCDwx/GroAiG4rObNyEZOwW7kYWSuHEEbl7DqiUe3fkqKX4zU63W',NULL,1,NULL,'active',NULL,NULL,NULL,NULL,'2025-12-25 16:23:20',0,NULL,'2025-12-24 00:51:55','2025-12-25 16:23:20',NULL);
/*!40000 ALTER TABLE `chm_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chm_vehicles`
--

DROP TABLE IF EXISTS `chm_vehicles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chm_vehicles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `plate` varchar(10) NOT NULL,
  `brand` varchar(50) NOT NULL,
  `model` varchar(100) NOT NULL,
  `year` year(4) NOT NULL,
  `color` varchar(30) NOT NULL,
  `renavam` varchar(20) DEFAULT NULL,
  `chassis` varchar(30) DEFAULT NULL,
  `fuel` enum('gasoline','ethanol','flex','diesel','electric','hybrid') NOT NULL DEFAULT 'flex',
  `category` enum('sedan','suv','van','bus','other') NOT NULL DEFAULT 'sedan',
  `ownership` varchar(20) DEFAULT 'proprio',
  `seats` tinyint(3) unsigned NOT NULL DEFAULT 4,
  `owner` enum('proprio','terceirizado') NOT NULL DEFAULT 'proprio',
  `owner_name` varchar(150) DEFAULT NULL,
  `owner_document` varchar(20) DEFAULT NULL,
  `insurance_company` varchar(100) DEFAULT NULL,
  `insurance_policy` varchar(50) DEFAULT NULL,
  `insurance_expiry` date DEFAULT NULL,
  `ipva_paid` tinyint(1) NOT NULL DEFAULT 0,
  `licensing_date` date DEFAULT NULL,
  `last_maintenance` date DEFAULT NULL,
  `next_maintenance` date DEFAULT NULL,
  `odometer` int(10) unsigned DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `status` enum('active','inactive','maintenance') NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_plate` (`plate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chm_vehicles`
--

LOCK TABLES `chm_vehicles` WRITE;
/*!40000 ALTER TABLE `chm_vehicles` DISABLE KEYS */;
/*!40000 ALTER TABLE `chm_vehicles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chm_vouchers`
--

DROP TABLE IF EXISTS `chm_vouchers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chm_vouchers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `booking_id` int(10) unsigned NOT NULL,
  `code` varchar(50) NOT NULL,
  `type` enum('voucher','receipt') NOT NULL DEFAULT 'voucher',
  `file_path` varchar(255) DEFAULT NULL,
  `sent_at` datetime DEFAULT NULL,
  `sent_to` varchar(150) DEFAULT NULL,
  `sent_method` enum('email','whatsapp','both') DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chm_vouchers`
--

LOCK TABLES `chm_vouchers` WRITE;
/*!40000 ALTER TABLE `chm_vouchers` DISABLE KEYS */;
/*!40000 ALTER TABLE `chm_vouchers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chm_whatsapp_messages`
--

DROP TABLE IF EXISTS `chm_whatsapp_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chm_whatsapp_messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `message_id` varchar(100) DEFAULT NULL,
  `phone` varchar(20) NOT NULL,
  `direction` enum('incoming','outgoing') NOT NULL,
  `type` enum('text','image','document','audio','video','template') NOT NULL DEFAULT 'text',
  `content` text NOT NULL,
  `template_name` varchar(100) DEFAULT NULL,
  `template_params` text DEFAULT NULL,
  `status` enum('pending','sent','delivered','read','failed') NOT NULL DEFAULT 'pending',
  `error_message` text DEFAULT NULL,
  `client_id` int(10) unsigned DEFAULT NULL,
  `driver_id` int(10) unsigned DEFAULT NULL,
  `booking_id` int(10) unsigned DEFAULT NULL,
  `sent_at` datetime DEFAULT NULL,
  `delivered_at` datetime DEFAULT NULL,
  `read_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chm_whatsapp_messages`
--

LOCK TABLES `chm_whatsapp_messages` WRITE;
/*!40000 ALTER TABLE `chm_whatsapp_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `chm_whatsapp_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chm_whatsapp_tags`
--

DROP TABLE IF EXISTS `chm_whatsapp_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chm_whatsapp_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tag` varchar(50) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `field_reference` varchar(100) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_tag` (`tag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chm_whatsapp_tags`
--

LOCK TABLES `chm_whatsapp_tags` WRITE;
/*!40000 ALTER TABLE `chm_whatsapp_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `chm_whatsapp_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chm_whatsapp_templates`
--

DROP TABLE IF EXISTS `chm_whatsapp_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chm_whatsapp_templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `category` varchar(50) NOT NULL,
  `content` text NOT NULL,
  `variables` text DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chm_whatsapp_templates`
--

LOCK TABLES `chm_whatsapp_templates` WRITE;
/*!40000 ALTER TABLE `chm_whatsapp_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `chm_whatsapp_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) NOT NULL,
  `checksum` varchar(64) NOT NULL,
  `ran_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `filename` (`filename`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-26  2:00:03
